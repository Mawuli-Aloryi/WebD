Assignment 2
Name: Daniel Mawuli Aloryi
Student ID: B00869955
email: danielaloryi@dal.ca
#Citations: N/A

If I were to implement dark mode, I'd give an 'id' attribute to the 'body' element. And in my external css style sheet, I'd set the background color of the body to black, using the id attribute (ps: this includes the header container which has already been set to a background color of steelblue. That code will be deleted since it'll affect the dark mode feature). After, I'll change the default color of all heading levels and paragraph texts from black to a much brighter color (eg. white) to make them more visible.

<!--Example Code - HTML-->
<body id="dark-mode">

<!--Example Code - CSS-->
#dark-mode
{
    background-color: black;
}
p
{
    color: white;
}
h1
{
    color: white;
}
h2
{
    color: white;
}
h3
{
    color: white;
}
h4
{
    color: white;
}


   




